#ifndef TUI_H
#define TUI_H

void centerprintw(char* text);

#endif
