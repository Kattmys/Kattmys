#ifndef GAME_H
#define GAME_H

typedef struct Cell {
    int value;
    int revealed;
    int flagged;
    int mine;
} Cell;

typedef struct Map {
    Cell** cells;
    int columns;
    int rows;
} Map;

struct Map* create_map(int rows, int columns);
void reveal(struct Map* map, int x, int y);
void generate_mines(struct Map* map, int mines);
void render_map(struct Map* map);
void free_map(struct Map* map);

#endif
