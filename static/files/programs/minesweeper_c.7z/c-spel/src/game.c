#include <stdlib.h>
#include <ncurses.h>
#include "game.h"

struct Map* create_map(int rows, int columns) {
    struct Map* map = malloc(sizeof(struct Map));
    if (!map) return NULL;

    map->rows = rows;
    map->columns = columns;
    map->cells = malloc(map->columns * sizeof(Cell*));
    if (!map->cells) { free(map); return NULL; }

    for (int x=0; x<map->columns; x++) {
        map->cells[x] = malloc(map->rows * sizeof(Cell));
        
        for (int y=0; y<map->rows; y++) {
            map->cells[x][y].value = 0;
            map->cells[x][y].revealed = 0;
            map->cells[x][y].flagged = 0;
            map->cells[x][y].mine = 0;
            // map->cells[x][y]->symbol
        }
    }

    return map;
}

// TODO:
// -[x] Fixa så oändlig rekursion funkar
// -[ ] Fixa så den kollar 
// -[ ]
// -[ ]
// -[ ]

void incr_around(Map* map, int rx, int ry)
{
    for (int x=-1; x<2; x++)
    {
        if (rx+x < 0 || rx+x >= map->columns) { continue; }

        for (int y=-1; y<2; y++)
        {
            if (ry+y < 0 || ry+y >= map->rows) { continue; }

            map->cells[rx+x][ry+y].value++;
        }
    }
}

void reveal_around(Map* map, int x, int y)
{
    for (int cx=-1; cx<2; cx++)
    {
        for (int cy=-1; cy<2; cy++)
        {
            int nx = x+cx;
            int ny = y+cy;
            if (nx < 0 || ny < 0 || nx >= map->columns || ny >= map->rows) continue;

            Cell* c = &map->cells[nx][ny];
            if (c->flagged == 1) continue;

            if (c->value == 0 && c->revealed == 0)
            {
                c->revealed = 1;
                reveal_around(map, nx, ny);
            }
            else
            {
                c->revealed = 1;
            }
        }
    }
}

void reveal(Map* map, int x, int y)
{
    Cell* c = &map->cells[x][y];
    if (c->flagged == 0)
    {
        c->revealed = 1;
    }

    reveal_around(map, x, y);
    return;
}

void generate_mines(Map* map, int mines) 
{
    for (int i=0; i<mines; i++) 
    {
        int rx = rand() % map->columns;
        int ry = rand() % map->rows;

        if (map->cells[rx][ry].mine == 0) 
        {
            map->cells[rx][ry].mine = 1;
            incr_around(map, rx, ry);

        }
        else 
        {
            i--;
        }
    }
}

void render_map(Map* map) {
    for (int x=0; x<map->columns; x++) 
    {
        for (int y=0; y<map->rows; y++) 
        {
            move(y*2, x*2);

            Cell c = map->cells[x][y];

            if (c.revealed) 
            {
                if (c.mine) 
                { printw("B"); }
                else
                { printw("%d", c.value); }
            } 
            else if (c.flagged) 
            { printw("!"); } 
            else 
            { printw("#"); } }
    }
}

void free_map(struct Map* map) 
{
    for (int x=0; x<map->columns; x++) 
    {
        free(map->cells[x]);
    }

    free(map->cells);
    free(map);
}
