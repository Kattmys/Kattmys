#include <string.h>
#include <ncurses.h>
#include "tui.h"

void centerprintw(char* text)
{
    int h, w, length, paddingy, paddingx;
    length = strlen(text);

    getmaxyx(stdscr, h, w);

    paddingy = (h / 2);
    paddingx = (w / 2) - (length / 2);

    move(paddingy, paddingx);
    printw(text);
}
