#include <stdlib.h>
#include <ncurses.h>
#include "game.h"
#include "tui.h"

#include <time.h>

#define WIDTH 30
#define HEIGHT 10
#define BUFFLEN 5

int main() 
{
    int running = 1;

    int x = WIDTH / 2;
    int y = HEIGHT / 2;

    char buffer[BUFFLEN];

    srand(time(NULL));

    initscr();
    cbreak();
    noecho();
    keypad(stdscr, TRUE);
    clear();

    struct Map* map = create_map(HEIGHT, WIDTH);
    generate_mines(map, 50);

while (running)
{
    for (int i=1; i<BUFFLEN; i++)
    {
        buffer[i-1] = buffer[i];
    }

    buffer[BUFFLEN - 1] = getch();

    switch (buffer[BUFFLEN - 1])
    {
        case 'q':
            running = 0;
            break;

        case 'k':
            y -= 1;
            break;

        case 'j':
            y += 1;
            break;

        case 'h':
            x -= 1;
            break;

        case 'l':
            x += 1;
            break;

        case 10:
        case KEY_ENTER:
            reveal(map, x/2, y/2);
            break;

        case 'i':
            if (map->cells[x/2][y/2].flagged == 0)
            { map->cells[x/2][y/2].flagged = 1; }
            else
            { map->cells[x/2][y/2].flagged = 0; }

        default:
            break;
    }

    clear();
    render_map(map);
    move(y, x);
    refresh();

}


    free_map(map);
    keypad(stdscr, FALSE);
    endwin();
    return 0;
}

